// import the model
const Todo = require("../models/Book");

// define route handler
// exports.createTodo is another way to export
exports.updateBook = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, author , publishYear} = req.body;
    const todo = await Todo.findByIdAndUpdate(
      { _id: id },
      { title, author, publishYear}
    );
    res.status(200).json({
      success: true,
      data: todo,
      message: "Updated",
    });
  } catch (err) {
    console.error(err);
    console.log(err);

    res.status(500) // internal server error
      .json({
        success: false,
        data: "internal server error",
        message: err.message,
      });
  }
};
