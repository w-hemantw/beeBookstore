// controllers/deleteBook.js
const Book = require('../models/Book');

exports.deleteBook = async (req, res) => {
  try {
    // Fetch all todo items from the database
    const { id } = req.params;
    const book = await Book.findByIdAndDelete(id);

    res.json({
      success: true,
      data: book,
      message: "Book deleted successfully",
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: err.message,
    });
  }
};
