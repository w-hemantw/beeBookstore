// import the model
const Book = require("../models/Book");

// define route handler
// exports.createTodo is another way to export
exports.createBook = async (req, res) => {
  try {
    // extract title, desc from request body
    const { title, author ,publishYear} = req.body;

    // create a new Todo Obj and insert in DB -> use create()
    const response = await Book.create({ title, author , publishYear});

    // send a json response with a success flag
    res.status(200).json({
      success: true,
      data: response,
      message: "Entry Created Successfully",
    });
  } catch (err) {
    console.error(err);
    console.log(err);

    res
      .status(500) // internal server error
      .json({
        success: false,
        data: "internal server error",
        message: err.message,
      });
  }
};